<?php

namespace App\Models;

use CodeIgniter\Model;

class UsersModel extends Model {
    protected $table = 'caps';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name', 'username', 'password', 'date_created'];

    // Validation rules
    protected $validationRules = [
        'name' => 'required|min_length[3]|max_length[255]',
        'username' => 'required|is_unique[caps.username]|min_length[3]|max_length[255]',
        'password' => 'required|min_length[6]',
    ];

    protected $validationMessages = [
        'username' => [
            'is_unique' => 'This username is already taken. Please choose another one.',
        ],
    ];

    public function getUserByUsername($username) {
        return $this->where('username', $username)->first();
    }
}
