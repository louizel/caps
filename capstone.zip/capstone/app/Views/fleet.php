<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fleet - UPS Delivery Service</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --ups-black: #000000;
            --ups-white: #ffffff;
            --ups-gray: #f0f0f0;
        }

        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            background-color: var(--ups-white);
            color: var(--ups-black);
        }

        .navbar {
            background-color: var(--ups-black);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .navbar-brand img {
            height: 40px;
        }

        .nav-link {
            color: var(--ups-white) !important;
            font-weight: 500;
        }

        .nav-link:hover {
            color: var(--ups-gray) !important;
        }

        footer {
            background-color: var(--ups-black);
            color: var(--ups-white);
        }

        .fleet-form {
            background-color: var(--ups-gray);
            border-radius: 10px;
            padding: 2rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="<?= base_url(); ?>">UPS</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url(); ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('book'); ?>">Book Now</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="<?= base_url('fleet'); ?>">Fleet</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('about'); ?>">About Us</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <h2 class="text-center mb-4">FLEET / DISPATCH</h2>
        <p>Details about the fleet go here.</p>

     
        <div class="fleet-form">
            <form method="post" action="<?= base_url('submit-fleet'); ?>">
                <div class="text-center">
                    <button type="submit" class="btn btn-primary btn-lg">Confirm and Track Booking</button>
                </div>
            </form>
        </div>
    </div>

    <footer class="py-4 mt-5">
        <div class="container text-center">
            <p>&copy; <?php echo date('Y'); ?> United Parcel Service of Philippines, Inc. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>