<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --ups-black: #000000;
            --ups-white: #ffffff;
            --ups-gray: #f0f0f0;
            --ups-dark-gray: #333333;
        }
        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            background-color: var(--ups-white);
            color: var(--ups-black);
        }
        .hero {
            background-color: var(--ups-black);
            color: var(--ups-white);
            padding: 4rem 0;
            text-align: center;
        }
        .container {
            margin-top: 5rem;
            max-width: 400px;
            padding: 2rem;
            background-color: var(--ups-gray);
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .btn-ups {
            background-color: var(--ups-black);
            color: var(--ups-white);
            border: 2px solid var(--ups-white);
            transition: all 0.3s ease;
        }
        .btn-ups:hover {
            background-color: var(--ups-white);
            color: var(--ups-black);
        }
    </style>
</head>
<body>

    <div class="hero">
        <h1 class="display-4 fw-bold">Login</h1>
        <p class="lead">Please enter your credentials to log in</p>
    </div>

    <div class="container">
        <form action="<?= base_url('/login'); ?>" method="post">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" name="username" id="username" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-ups">Login</button>
        </form>
        <p class="mt-3">Don't have an account? <a href="<?= base_url('/register'); ?>">Sign up here</a></p>
    </div>

</body>
</html>
