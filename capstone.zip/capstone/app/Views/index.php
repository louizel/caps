<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UPS Delivery Service</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --ups-black: #000000;
            --ups-white: #ffffff;
            --ups-gray: #f0f0f0;
            --ups-dark-gray: #333333;
        }

        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            background-color: var(--ups-white);
            color: var(--ups-black);
            line-height: 1.6;
        }

        .navbar {
            background-color: var(--ups-black);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .navbar-brand img {
            height: 40px;
        }

        .nav-link {
            color: var(--ups-white) !important;
            font-weight: 500;
        }

        .nav-link:hover {
            color: var(--ups-gray) !important;
        }

        .hero {
            background-color: var(--ups-black);
            color: var(--ups-white);
            padding: 4rem 0;
            position: relative;
            overflow: hidden;
        }

        .hero::after {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, rgba(255, 255, 255, 0.1) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.1) 50%, rgba(255, 255, 255, 0.1) 75%, transparent 75%, transparent);
            background-size: 100px 100px;
            opacity: 0.1;
        }

        .btn-ups {
            background-color: var(--ups-black);
            color: var(--ups-white);
            border: 2px solid var(--ups-white);
            transition: all 0.3s ease;
        }

        .btn-ups:hover {
            background-color: var(--ups-white);
            color: var(--ups-black);
        }

        .feature-icon {
            font-size: 2.5rem;
            color: var(--ups-black);
            transition: all 0.3s ease;
        }

        .card:hover .feature-icon {
            transform: scale(1.1);
        }

        .card {
            border: none;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }

        footer {
            background-color: var(--ups-black);
            color: var(--ups-white);
        }

        .section-title {
            position: relative;
            display: inline-block;
            padding-bottom: 10px;
        }

        .section-title::after {
            content: "";
            position: absolute;
            left: 0;
            bottom: 0;
            width: 50px;
            height: 2px;
            background-color: var(--ups-black);
        }

        .service-item {
            text-align: center;
            padding: 2rem;
            background-color: var(--ups-gray);
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .service-item:hover {
            background-color: var(--ups-dark-gray);
            color: var(--ups-white);
        }

        .service-item:hover .feature-icon {
            color: var(--ups-white);
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="<?= base_url(); ?>">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url(); ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('book'); ?>">Book Now</a>
                    </li>
                    <a class="nav-link" href="<?= base_url('about'); ?>">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('reports'); ?>">Reports</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="hero text-center">
        <div class="container">
            <h1 class="display-4 fw-bold">UPS Delivery Service</h1>
            <p class="lead">Fast and Reliable Delivery Solutions</p>
            <a href="<?= base_url('book'); ?>" class="btn btn-ups btn-lg mt-3">Book Now</a>
        </div>
    </div>

    <div class="container my-5">
        <h2 class="text-center mb-5 section-title">Our Services</h2>
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="service-item">
                    <i class="fas fa-shipping-fast feature-icon mb-3"></i>
                    <h5>Same-Day Delivery</h5>
                    <p>Fast and reliable delivery within hours!</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="service-item">
                    <i class="fas fa-truck feature-icon mb-3"></i>
                    <h5>Express Shipping</h5>
                    <p>Quick delivery options for urgent needs</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="service-item">
                    <i class="fas fa-map-marked-alt feature-icon mb-3"></i>
                    <h5>Real-Time Tracking</h5>
                    <p>Track your shipment easily at every stage</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="service-item">
                    <i class="fas fa-globe feature-icon mb-3"></i>
                    <h5>Wide Coverage</h5>
                    <p>Deliveries across the city and beyond</p>
                </div>
            </div>
            <div class="col-md-6 mb-4">
                <div class="service-item">
                    <i class="fa-solid fa-peso-sign feature-icon mb-3"></i>

                    <h5>Affordable Rates</h5>
                    <p>Competitive pricing tailored to your needs</p>
                </div>
            </div>
        </div>
    </div>

    <footer class="py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p>&copy; <?php echo date('Y'); ?> UPS Delivery Service. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <a href="#" class="text-white me-2">Privacy Policy</a>
                    <a href="#" class="text-white me-2">Terms of Use</a>
                    <a href="#" class="text-white">Accessibility</a>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>