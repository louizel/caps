<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --ups-black: #000000;
            --ups-white: #ffffff;
            --ups-gray: #f0f0f0;
            --ups-dark-gray: #333333;
            --ups-blue: #007bff;
        }

        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            background-color: var(--ups-white);
            color: var(--ups-black);
            line-height: 1.6;
        }

        header {
            background-color: var(--ups-black);
            padding: 20px;
            text-align: center;
            color: var(--ups-white);
        }

        nav a {
            margin: 0 15px;
            text-decoration: none;
            color: var(--ups-white);
        }

        nav a:hover {
            text-decoration: underline;
        }

        main {
            padding: 40px 20px;
        }

        section {
            max-width: 800px;
            margin: auto;
            padding: 20px;
            background-color: var(--ups-gray);
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1,
        h2 {
            color: var(--ups-dark-gray);
        }

        footer {
            background-color: var(--ups-black);
            color: var(--ups-white);
            text-align: center;
            padding: 15px;
            margin-top: 20px;
        }

        .environment {
            color: #777;
        }

        .outer-container {
            background-color: var(--ups-gray);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .inner-container {
            width: 100px;
            height: 100px;
            background-color: #ccc;
            border-radius: 5px;
            margin: 0 auto 10px;
        }
    </style>
</head>

<body>
    <header>
        <h1>UPS Delivery Service</h1>
        <nav>
            <a href="<?= base_url(); ?>">Home</a>
            <a href="<?= base_url('book'); ?>">Book Now</a>
            <a href="<?= base_url('about'); ?>">About Us</a>
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('reports'); ?>">Reports</a>
            </li>
        </nav>
    </header>
    <main class="container my-4">
        <section>
            <h1 class="mb-4">About Us</h1>
            <p>UPS Courier Service is your trusted partner for fast, reliable, and efficient package delivery, ensuring your shipments reach their destination safely and on time.</p>

            <h2 class="mt-4">What We Seek to Achieve</h2>
            <p>Grow our global business by serving the logistics needs of customers, offering excellence and value in all that we do. Maintain a financially strong company-with broad employee ownership-that provides a long-term competitive return to our shareowners. Inspire our people and business partners to do their best, offering opportunities for personal development and success. Lead by example as a responsible, caring, and sustainable company making a difference in the communities we serve.</p>

            <h2 class="mt-4">Our History</h2>
            <p>Founded on August 28, 1907, United Parcel Service (UPS) began as a messenger service in Seattle and has since transformed into a global logistics leader. Known for its reliable courier services, UPS has continuously embraced technology to enhance efficiency and customer satisfaction. Today, UPS delivery couriers are recognized worldwide for their professionalism and commitment to timely deliveries.</p>

            <h2 class="mt-4">Our Services</h2>
            <p>We offer a range of delivery options, including same-day delivery, express shipping, and real-time tracking, ensuring that your package reaches its destination quickly and safely.</p>

            <h2 class="mt-4">The Developers</h2>
            <p>The developers are currently studying at FEU Institute of Technology with the course of Bachelor of Science in Information Technology with a Specialization in Web and Mobile Applications. With a strong foundation in software development and a passion for innovation, they are dedicated to creating efficient, user-friendly solutions that meet today’s digital demands.</p>

            <div class="container my-4">
                <div class="row text-center">
                    <div class="col-2 outer-container member1">
                        <div class="inner-container"></div>
                        <p>Member 1</p>
                    </div>
                    <div class="col-2 outer-container member2">
                        <div class="inner-container"></div>
                        <p>Member 2</p>
                    </div>
                    <div class="col-2 outer-container member3">
                        <div class="inner-container"></div>
                        <p>Member 3</p>
                    </div>
                    <div class="col-2 outer-container member4">
                        <div class="inner-container"></div>
                        <p>Member 4</p>
                    </div>
                    <div class="col-2 outer-container member5">
                        <div class="inner-container"></div>
                        <p>Member 5</p>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <footer>
        <div class="environment">&copy; <?php echo date('Y'); ?> UPS Delivery Service. All rights reserved.</div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>