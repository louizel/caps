<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Your Booking - UPS Delivery Service</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --ups-black: #000000;
            --ups-white: #ffffff;
            --ups-gray: #f0f0f0;
            --ups-blue: #007bff;
        }

        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            background-color: var(--ups-white);
            color: var(--ups-black);
            line-height: 1.6;
        }

        .navbar {
            background-color: var(--ups-black);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .hero {
            background-color: var(--ups-black);
            color: var(--ups-white);
            padding: 2rem 0;
        }

        .tracking-form {
            background-color: var(--ups-gray);
            border-radius: 10px;
            padding: 2rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        footer {
            background-color: var(--ups-black);
            color: var(--ups-white);
        }

        .map-container {
            position: relative;
            height: 300px;
            margin-top: 20px;
        }

        .map {
            width: 100%;
            height: 100%;
            border: 0;
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="<?= base_url(); ?>">UPS</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="<?= base_url(); ?>">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= base_url('book'); ?>">Book Now</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= base_url('about'); ?>">About Us</a></li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('reports'); ?>">Reports</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="hero text-center">
        <div class="container">
            <h1 class="display-4 fw-bold">Track Your Booking</h1>
            <p class="lead">Stay informed about your delivery status</p>
        </div>
    </div>

    <div class="container my-5">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="tracking-form">
                    <h2 class="text-center mb-4">Enter your booking details to track your delivery</h2>
                    <form method="post" action="<?= base_url('submit-tracking'); ?>">
                        <div class="mb-3">
                            <label for="tracking_number" class="form-label">Tracking Number:</label>
                            <input type="text" class="form-control" id="tracking_number" name="tracking_number" required>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-ups btn-lg">Track Now</button>
                        </div>
                    </form>
                </div>

                <div class="mt-5">
                    <h3>This is your cargo's route</h3>
                    <div class="map-container">
                        <!-- replace needed ha!!!!!! -->
                        <iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.057259163069!2d-122.40673478468185!3d37.78449827975776!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858084c2e4086d%3A0x5f2b68b602c4a0bc!2sSan%20Francisco%2C%20CA!5e0!3m2!1sen!2sus!4v1616400538702!5m2!1sen!2sus" allowfullscreen="" loading="lazy"></iframe>
                    </div>
                </div>

                <div class="mt-5">
                    <h3>Rate Card</h3>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Weight (kg)</th>
                                <th>Price (₱)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>0-5</td>
                                <td>1000.00</td>
                            </tr>
                            <tr>
                                <td>6-10</td>
                                <td>1500.00</td>
                            </tr>
                            <tr>
                                <td>11-20</td>
                                <td>2500.00</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="mt-5">
                    <h3>Vendor Tracking Company</h3>
                    <p>UPS trucks</p>
                </div>
            </div>
        </div>
    </div>

    <footer class="py-4">
        <div class="container text-center">
            <p>&copy; <?php echo date('Y'); ?> UPS Delivery Service. All rights reserved.</p>
            <a href="#" class="text-white me-2">Privacy Policy</a>
            <a href="#" class="text-white me-2">Terms of Use</a>
            <a href="#" class="text-white">Accessibility</a>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>