<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;
use CodeIgniter\Router\RouteCollection;

$routes = Services::routes();

if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}

$routes->get('/', 'Home::index'); // Home page
$routes->get('/book', 'Home::book'); // Book Now page
$routes->get('/fleet', 'Home::fleet'); // Fleet page
$routes->get('/about', 'Home::about'); // About Us page

// Authentication routes
$routes->get('/register', 'Auth::register'); // Show registration form
$routes->post('/register', 'Auth::doRegister'); // Handle registration submission
$routes->get('/login', 'Auth::login'); // Show login form
$routes->post('/login', 'Auth::doLogin'); // Handle login submission
$routes->post('/submit-booking', 'Home::submitBooking'); // Handle booking submission
$routes->post('/submit-fleet', 'Home::track'); // Redirect to track page
$routes->post('/submit-fleet', 'Home::submitFleet'); // Route for fleet form submission
$routes->get('reports', 'Home::reports');//Route for reports page
