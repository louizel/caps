<?php

namespace App\Controllers;

use App\Models\UsersModel;
use CodeIgniter\Controller;

class Auth extends Controller {
    
    // Load the registration view
    public function register() {
        return view('register_view'); 
    }

    // Handle registration submission
    public function doRegister() {
        $model = new UsersModel();
        
        // Get input values from the form
        $data = [
            'name' => $this->request->getPost('name'),
            'username' => $this->request->getPost('username'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT), // Hash the password
            'date_created' => date('Y-m-d'), // Current date
        ];
        
        // Insert data into the database
        if ($model->insert($data)) {
            return redirect()->to('/login'); // Redirect to login page after successful registration
        } else {
            return redirect()->back()->with('error', 'Registration failed.'); // Redirect back with error message
        }
    }

    // Load the login view
    public function login() {
        return view('login_view'); 
    }

    // Handle login submission
    public function doLogin() {
        $model = new UsersModel();

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        // Find the user by username
        $user = $model->where('username', $username)->first();

        // Verify the password and check user existence
        if ($user && password_verify($password, $user['password'])) {
            // Set session data
            session()->set('loggedIn', true);
            session()->set('username', $user['username']);

            return redirect()->to('/'); // Redirect to the index page after login
        } else {
            return redirect()->back()->with('error', 'Invalid username or password'); // Redirect back with error message
        }
    }
}
