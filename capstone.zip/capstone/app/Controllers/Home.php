<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        $data['title'] = 'UPS Delivery Service';
        return view('index', $data);
    }

    public function book(): string
    {
        $data['title'] = 'Book Now - UPS Delivery Service';
        return view('book', $data);
    }

    public function fleet(): string
    {
        $data['title'] = 'Fleet - UPS Delivery Service';
        return view('fleet', $data);
    }

    public function track(): string
    {
        $data['title'] = 'Track Your Delivery - UPS Delivery Service';
        return view('track', $data);
    }

    public function customerService(): string
    {
        $data['title'] = 'Customer Service - UPS Delivery Service';
        return view('customer_service', $data);
    }

    public function about(): string
    {
        $data['title'] = 'About Us - UPS Delivery Service';
        return view('about', $data);
    }

    public function reports(): string
    {
        $data['title'] = 'Monthly Report - UPS Delivery Service';
        return view('reports', $data);
    }

    public function submitBooking()
    {
        return redirect()->to('fleet');
    }

    public function submitFleet()
    {
        return redirect()->to('track');
    }
}
